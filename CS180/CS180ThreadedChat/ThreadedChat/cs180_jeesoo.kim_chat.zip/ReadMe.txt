Window
 1. Go to ThreadedChatSolution folder.
 2. Open Solution File (ThreadedChatSolution.sln)
 3. Press build button or Ctrl + Shift + B


Ubuntu
 1. Go to All of it folder.
 2. Open a command window
 3. Type 'make'
 	- Then make file build it, give you chat_server, chat_browser, chat_writer