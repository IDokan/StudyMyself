How to build your program

open cmd or bash and type it
	g++ -std=c++17 -o demo.exe main.cpp

How to interact with your program

Open main.cpp to take a look at a bunch of code that I wrote. If you want to see a result of each function, run demo.exe with test_number
	(0 -> autoMultipleInitializerDemo())
	(1 -> selectionSequenceWithInitializersDemo())
	(2 -> IfConstexprDemo())

What you learned from creating the demo
	I've learned how to use C++17 new features by myself, with my hand.